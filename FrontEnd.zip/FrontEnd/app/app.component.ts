import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as Highcharts from 'highcharts';
import { DataService } from './data.service';
import axios from 'axios';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  dashboardQuote = "Welcome to Enterprise Co-Pilot. Your AI assistant is here to help!";
  currentSection = 'dashboard';
  showValidation = false;
  isDarkTheme = true;
  selectedFile: File | null = null;
  queryInput: string = '';
  chatMessages: { sender: string, message: string }[] = [];
  isLoading = false;
  Highcharts = Highcharts;
  accuracyChartOptions: Highcharts.Options = {};
  coherenceChartOptions: Highcharts.Options = {};

  private readonly API_BASE_URL = 'http://10.174.21.5:8000/upload';
  private readonly CHAT_API_URL = 'http://localhost:5000/retrieve';
  private readonly DATA_API_URL = 'http://localhost:5000/data';

  constructor(private dataService: DataService, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadAccuracyData();
    this.loadCoherenceData();
  }

  loadAccuracyData(): void {
    this.dataService.getAccuracyData().subscribe(
      (data: any) => {
        this.accuracyChartOptions = {
          chart: {
            type: 'pie',
            backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
            style: { fontFamily: 'Roboto, sans-serif' }
          },
          title: {
            text: 'Accuracy Chart',
            style: { color: this.isDarkTheme ? '#ffffff' : '#000000' }
          },
          plotOptions: {
            pie: {
              innerSize: '50%',
              colors: ['#28a745', '#dc3545', '#007bff', '#ffc107'],
              dataLabels: {
                style: { color: this.isDarkTheme ? '#ffffff' : '#000000' }
              }
            }
          },
          series: [{
            type: 'pie',
            name: 'Accuracy',
            data: [
              { name: 'Correct', y: data.correct || 80, color: '#28a745' },
              { name: 'Incorrect', y: data.incorrect || 10, color: '#dc3545' },
              { name: 'Review Needed', y: 5, color: '#007bff' },
              { name: 'Other', y: 5, color: '#ffc107' }
            ]
          }]
        };
      },
      (error: any) => {
        console.error('Error loading accuracy data', error);
        this.accuracyChartOptions = this.getDefaultChartOptions('Accuracy Chart');
      }
    );
  }

  loadCoherenceData(): void {
    this.dataService.getCoherenceData().subscribe(
      (data: any) => {
        this.coherenceChartOptions = {
          chart: {
            type: 'pie',
            backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
            style: { fontFamily: 'Roboto, sans-serif' }
          },
          title: {
            text: 'Coherence Chart',
            style: { color: this.isDarkTheme ? '#ffffff' : '#000000' }
          },
          plotOptions: {
            pie: {
              innerSize: '50%',
              colors: ['#007bff', '#ffc107'],
              dataLabels: {
                style: { color: this.isDarkTheme ? '#ffffff' : '#000000' }
              }
            }
          },
          series: [{
            type: 'pie',
            name: 'Coherence',
            data: [
              { name: 'Correct', y: data.correct || 80, color: '#28a745' },
              { name: 'Incorrect', y: data.incorrect || 10, color: '#dc3545' },
              { name: 'Review Needed', y: 5, color: '#007bff' },
              { name: 'Other', y: 5, color: '#ffc107' }
            ]
          }]
        };
      },
      (error: any) => {
        console.error('Error loading coherence data', error);
        this.coherenceChartOptions = this.getDefaultChartOptions('Coherence Chart');
      }
    );
  }

  setSection(section: string): void {
    this.currentSection = section;
    if (section === 'accuracy') {
      this.loadAccuracyData();
    } else if (section === 'coherence') {
      this.loadCoherenceData();
    }
  }

  toggleValidation(): void {
    this.showValidation = !this.showValidation;
  }

  toggleTheme(): void {
    this.isDarkTheme = !this.isDarkTheme;
  }

  async submitQuery() {
    if (this.queryInput.trim()) {
      const temp = this.queryInput;
      this.queryInput = '';
      this.chatMessages.push({ sender: 'User', message: temp });
      this.isLoading = true;

      try {
        const response = await axios.post(this.CHAT_API_URL, { query: temp });
        this.chatMessages.push({ sender: 'bot', message: response.data || 'No answer provided' });
      } catch (error) {
        console.error('Error sending query:', error);
        this.chatMessages.push({ sender: 'bot', message: 'Sorry, something went wrong.' });
      } finally {
        this.isLoading = false;
      }
    }
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('file', file);
      axios.post(this.API_BASE_URL, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      .then(response => console.log('File uploaded successfully:', response))
      .catch(error => console.error('Error uploading file:', error));
    }
  }


  onDataTypeChange(event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    const selectedValue = selectElement.value;

    // Assuming job IDs are available in a variable, array, or fetched from somewhere
    const jobIds = [632488232928544, 831648292028248, 835937312369922]; // Example job IDs, replace with actual data

    axios.post(this.DATA_API_URL, { 
        dataType: selectedValue, 
        jobIds: jobIds // Send job IDs as part of the request body 
      })
      .then(response => console.log('Data type and job IDs sent successfully:', response))
      .catch(error => console.error('Error sending data type and job IDs:', error));
  }

  getDefaultChartOptions(chartTitle: string): Highcharts.Options {
    return {
      chart: { type: 'pie', backgroundColor: '#ffffff' },
      title: { text: chartTitle },
      series: [{
        type: 'pie',
        name: 'Data',
        data: [
          { name: 'Placeholder', y: 100 }
        ]
      }]
    };
  }
}
