import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {

 
  constructor(private http: HttpClient) {}


  

  // Fetch accuracy data for accuracy chart
  getAccuracyData(): Observable<any> {
    return this.http.get<any>('assets/accuracy-data.json')
      .pipe(
        catchError(this.handleError)
      );
  }

 
  getCoherenceData(): Observable<any> {
    return this.http.get<any>('assets/coherence-data.json')
      .pipe(
        catchError(this.handleError)
      );
  }


  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}
