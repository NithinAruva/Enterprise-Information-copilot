// import { Component, OnInit } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import * as Highcharts from 'highcharts';

// @Component({
//   selector: 'app-root',
//   // templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent implements OnInit {

//   dashboardQuote = "Welcome to Enterprise Co-Pilot. Your AI assistant is here to help!";
//   queryResult: string | null = null;
//   currentSection = 'dashboard'; 
//   showValidation = false;
//   isDarkTheme = true;
//   selectedFile: File | null = null;

//   Highcharts = Highcharts;
//   accuracyChartOptions: Highcharts.Options = {};
//   coherenceChartOptions: Highcharts.Options = {};

//   private readonly API_BASE_URL = 'http://localhost:5000/upload'; 
//   private readonly DATABRICKS_API_URL = 'https://<your-databricks-instance>/api/2.0/dbfs/put'; 
//   private readonly TOKEN = '<your-databricks-token>'; 

  

//   ngOnInit(): void {
    
//     // this.loadAccuracyData();
//     // this.loadCoherenceData();
//   }

// // loadAccuracyData(): void {
// //   this.dataService.getAccuracyData().subscribe(
// //     data => {
// //       this.accuracyChartOptions = {
// //         chart: {
// //           type: 'pie',
// //           backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
// //           style: {
// //             fontFamily: 'Roboto, sans-serif'
// //           }
// //         },
// //         title: {
// //           text: 'Accuracy Chart',
// //           style: {
// //             color: this.isDarkTheme ? '#ffffff' : '#000000'
// //           }
// //         },
// //         plotOptions: {
// //           pie: {
// //             innerSize: '50%', // For donut chart
// //             colors: ['#28a745', '#dc3545', '#007bff', '#ffc107'], // Updated color palette
// //             dataLabels: {
// //               style: {
// //                 color: this.isDarkTheme ? '#ffffff' : '#000000'
// //               }
// //             }
// //           }
// //         },
// //         series: [{
// //           type: 'pie',
// //           name: 'Accuracy',
// //           data: [
// //             { name: 'Correct', y: data.correct || 80, color: '#28a745' }, // 80% with green
// //             { name: 'Incorrect', y: data.incorrect || 10, color: '#dc3545' }, // 10% red
// //             { name: 'Review Needed', y: 5, color: '#007bff' }, // Blue for another portion
// //             { name: 'Other', y: 5, color: '#ffc107' } // Yellow for another portion
// //           ]
// //         }]
// //       };
// //     },
// //     error => {
// //       console.error('Error loading accuracy data', error);
// //       this.accuracyChartOptions = {
// //         chart: {
// //           type: 'pie',
// //           backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
// //           style: {
// //             fontFamily: 'Roboto, sans-serif'
// //           }
// //         },
// //         title: {
// //           text: 'Accuracy Chart',
// //           style: {
// //             color: this.isDarkTheme ? '#ffffff' : '#000000'
// //           }
// //         },
// //         plotOptions: {
// //           pie: {
// //             innerSize: '50%', // For donut chart
// //             colors: ['#28a745', '#dc3545', '#007bff', '#ffc107'], // Updated colors
// //             dataLabels: {
// //               style: {
// //                 color: this.isDarkTheme ? '#ffffff' : '#000000'
// //               }
// //             }
// //           }
// //         },
// //         series: [{
// //           type: 'pie',
// //           name: 'Accuracy',
// //           data: [
// //             { name: 'Correct', y: 80, color: '#28a745' }, // 80% green
// //             { name: 'Incorrect', y: 10, color: '#dc3545' }, // 10% red
// //             { name: 'Review Needed', y: 5, color: '#007bff' }, // 5% blue
// //             { name: 'Other', y: 5, color: '#ffc107' } // 5% yellow
// //           ]
// //         }]
// //       };
// //     }
// //   );
// // }

 
//   loadCoherenceData(): void {
//     this.dataService.getCoherenceData().subscribe(
//       data => {
//         this.coherenceChartOptions = {
//           chart: {
//             type: 'pie',
//             backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
//             style: {
//               fontFamily: 'Roboto, sans-serif'
//             }
//           },
//           title: {
//             text: 'Coherence Chart',
//             style: {
//               color: this.isDarkTheme ? '#ffffff' : '#000000'
//             }
//           },
//           plotOptions: {
//             pie: {
//               innerSize: '50%', // For donut chart
//               colors: ['#007bff', '#ffc107'],
//               dataLabels: {
//                 style: {
//                   color: this.isDarkTheme ? '#ffffff' : '#000000'
//                 }
//               }
//             }
//           },
//           series: [{
//             type: 'pie',
//             name: 'Coherence',
//             data: [
//               { name: 'Correct', y: 80, color: '#28a745' }, // 80% green
//               { name: 'Incorrect', y: 10, color: '#dc3545' }, // 10% red
//               { name: 'Review Needed', y: 5, color: '#007bff' }, // 5% blue
//               { name: 'Other', y: 5, color: '#ffc107' } // 5% yellow
//             ]
//           }]
//         };
//       },
//       error => {
//         console.error('Error loading coherence data', error);
//         this.coherenceChartOptions = {
//           chart: {
//             type: 'pie',
//             backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
//             style: {
//               fontFamily: 'Roboto, sans-serif'
//             }
//           },
//           title: {
//             text: 'Coherence Chart',
//             style: {
//               color: this.isDarkTheme ? '#ffffff' : '#000000'
//             }
//           },
//           plotOptions: {
//             pie: {
//               innerSize: '50%', // For donut chart
//               colors: ['#007bff', '#ffc107'],
//               dataLabels: {
//                 style: {
//                   color: this.isDarkTheme ? '#ffffff' : '#000000'
//                 }
//               }
//             }
//           },
//           series: [{
//             type: 'pie',
//             name: 'Coherence',
//             data: [
//               { name: 'Correct', y: 80, color: '#28a745' }, // 80% green
//               { name: 'Incorrect', y: 10, color: '#dc3545' }, // 10% red
//               { name: 'Review Needed', y: 5, color: '#007bff' }, // 5% blue
//               { name: 'Other', y: 5, color: '#ffc107' } // 5% yellow
//             ]
//           }]
//         };
//       }
//     );
//   }

//   // Set the current section and reload data accordingly
//   setSection(section: string): void {
//     this.currentSection = section;
//     if (section === 'accuracy') {
//       this.loadAccuracyData();
//     } else if (section === 'coherence') {
//       this.loadCoherenceData();
//     }
//   }

//   toggleValidation(): void {
//     this.showValidation = !this.showValidation;
//   }

//   submitQuery(query: string): void {
//     try {
//       // Simulate an API call or other query handling logic
//       this.queryResult = `You asked: ${query}. This is a mock result.`;
//     } catch (error) {
//       console.error('Error submitting query', error);
//       this.queryResult = 'An error occurred while processing your query.';
//     }
//     this.currentSection = 'dashboard'; // Ensure dashboard is displayed
//   }

//   onFileChange(event: any): void {
//     this.selectedFile = event.target.files[0];
//   }

//   uploadFile(): void {
//     if (this.selectedFile) {
//       const formData = new FormData();
//       formData.append('file', this.selectedFile);
//       formData.append('path', '/mnt/your-mount-point/' + this.selectedFile.name);

//       this.http.post(this.API_BASE_URL, formData).subscribe(
//         response => {
//           console.log('File uploaded successfully:', response);
//         },
//         error => {
//           console.error('Error uploading file:', error);
//         }
//       );
//     } else {
//       console.error('No file selected');
//     }
//   }

//   toggleTheme(): void {
//     this.isDarkTheme = !this.isDarkTheme;
//     document.body.classList.toggle('light-theme', !this.isDarkTheme);
//     document.body.classList.toggle('dark-theme', this.isDarkTheme);
//     this.updateChartThemes();
//   }

//   private updateChartThemes(): void {
//     Highcharts.setOptions({
//       chart: {
//         backgroundColor: this.isDarkTheme ? '#2a2a2b' : '#ffffff',
//         style: {
//           fontFamily: 'Roboto, sans-serif'
//         }
//       },
//       title: {
//         style: {
//           color: this.isDarkTheme ? '#ffffff' : '#000000'
//         }
//       },
//       xAxis: {
//         labels: {
//           style: {
//             color: this.isDarkTheme ? '#ffffff' : '#000000'
//           }
//         }
//       },
//       yAxis: {
//         labels: {
//           style: {
//             color: this.isDarkTheme ? '#ffffff' : '#000000'
//           }
//         }
//       }
//     });
//   }
// }
